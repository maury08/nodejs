const data = [
    {
        fullName: "Carmen Lopez",
        email: "c@gmail.com",
        password: ""
    }
]

module.exports ={
    data
}